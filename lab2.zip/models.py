import pandas as pd
from data_functions import clean_data, pipeline_build
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

df = clean_data()
TARGET_COL = "Classification"

x = df.drop(columns=[TARGET_COL])
y = df[TARGET_COL]

train_x, test_x, train_y, test_y  = train_test_split(x, y, test_size=0.2, random_state=42)
pipeline = pipeline_build(train_x, train_y, LogisticRegression())

def check_scaler() :
    preprocessor = pipeline.named_steps['preprocessing']

# Transform numeric features only
    num_features = preprocessor.transformers_[0][2]
    scaled_values = preprocessor.named_transformers_['num_preproc'].transform(train_x[num_features])

# Wrap into a DataFrame for readability
    scaled_df = pd.DataFrame(scaled_values, columns=num_features)
    print("\nScaled numeric feature summary:")
    print(scaled_df.head())

def check_data_types() :
    print("Data shape:", df.shape)
    print("Missing values\n", df.isna().sum())
    print("Data types:\n", df.dtypes)

if __name__ == "__main__":
    check_scaler()
    check_data_types()
